function changename(){
    var name=document.querySelector("#namechange");
    name.innerText=("Joe Adams")
}


function remove1(){
    document.querySelector('.icon1',).remove();
    document.querySelector('.icon2',).remove()
    document.querySelector('.todd').remove();
}

function remove2(){
    document.querySelector('.icon3',).remove();
    document.querySelector('.icon4',).remove()
    document.querySelector('.phil').remove();
}


function minus(){
    decrease=document.querySelector('.badge');
    decrease.innerHTML=parseInt(decrease.innerHTML)-1
}

function plus(){
    increase=document.querySelector('.badge1')
    increase.innerHTML=parseInt(increase.innerHTML)+1
}


